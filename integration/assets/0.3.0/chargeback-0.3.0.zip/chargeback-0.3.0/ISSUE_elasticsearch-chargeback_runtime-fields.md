# Billing transform runtime field: Cannot iterate over [java.lang.String] on deployment_tags

## Summary

The `logs-chargeback.billing_cluster_cost` transform fails with a Painless script error when `ess.billing.deployment_tags` is indexed as a single string instead of an array. The runtime mapping for `deployment_group` uses `for (tag in params._source.ess.billing.deployment_tags)`, which throws when the value is a string.

## Environment

- Transform: `logs-chargeback.billing_cluster_cost` (e.g. default-0.3.0)
- Observed on branch: `wip/onprem-billing-integration` (integrations repo)
- Elasticsearch 9.2.2 (from stack trace)

## Error

```
Transform encountered an exception: [Validation Failed: 1: Failed to test query, received status: BAD_REQUEST;]; Will automatically retry [1/-1]
org.elasticsearch.common.ValidationException: Validation Failed: 1: Failed to test query, received status: BAD_REQUEST;
...
Caused by: org.elasticsearch.action.search.SearchPhaseExecutionException: all shards failed
...
Caused by: org.elasticsearch.script.ScriptException: runtime error
Caused by: java.lang.IllegalArgumentException: Cannot iterate over [java.lang.String]
```

## Root cause

The runtime script assumes `params._source.ess.billing.deployment_tags` is always iterable (a list). When the source sends or maps `deployment_tags` as a single string, Painless throws because you cannot use `for (tag in ...)` on a String.

## Fix

Handle both `List` and `String` in the Painless script:

```painless
if (params._source?.ess?.billing?.deployment_tags != null) {
  def tags = params._source.ess.billing.deployment_tags;
  if (tags instanceof List) {
    for (tag in tags) {
      if (tag.startsWith('chargeback_group:')) {
        emit(tag.substring('chargeback_group:'.length()));
        return;
      }
    }
  } else if (tags instanceof String) {
    if (tags.startsWith('chargeback_group:')) {
      emit(tags.substring('chargeback_group:'.length()));
      return;
    }
  }
}
emit('');
```

Apply this as the `runtime_mappings.deployment_group.script.source` in the billing_cluster_cost transform definition (e.g. in the transform YAML that ships with the chargeback integration).

## References

- Integrations repo: chargeback transform at `packages/chargeback/elasticsearch/transform/billing_cluster_cost/transform.yml`
- Related: deployment group extraction from tags `chargeback_group:<group_name>`
